executable name smallsh
Program works by running this line. gcc --std=gnu99 -g -o smallsh smallsh.c
